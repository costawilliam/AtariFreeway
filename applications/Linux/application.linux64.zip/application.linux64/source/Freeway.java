import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Freeway extends PApplet {

PImage Backgroud, Char;
PImage car0, car1, car2, car3;

int x = 550;
int y = 630;
int level = 1;
int retry = 0;
int level_previous;
Cars[] cars = new Cars[11];

public void setup(){
  
  Backgroud = loadImage("image/Backgroud.png");
  Char= loadImage("image/Char.png");
  car0= loadImage("image/car0.png"); 
  car1= loadImage("image/car1.png"); 
  car2= loadImage("image/car2.png"); 
  car3= loadImage("image/car3.png");

  for (int i = 0; i < cars.length; i++ ) {
    int style = (int) random(0,4);
    int pos_x = (int) random(0,1000);
    cars[i] = new Cars(pos_x, 579 - (51*i),style);
  }

  for (int i = 0; i < cars.length; i++ ) {
    println("velocidade inicial do carro "+ i + " = "+ cars[i].speed);
  }

  image(Backgroud, 0, 0);
  image(Char, x, y, Char.width, Char.height); 

  for (int i = 0; i < cars.length; i++ ) {
    cars[i].display(cars[i].style); 
    cars[i].update(0);
  }
}

public void draw() {
  collision();
  image(Backgroud, 0, 0);
  image(Char, x, y, Char.width, Char.height); 

  for (int i = 0; i < cars.length; i++ ) {
    cars[i].display(cars[i].style);
    cars[i].update(0);
  }

  textSize(48);
  fill(0xff9D0606);
  text(level, 75, 42);
}

public void keyPressed(){
  switch (key) { 
    case 'w':
    case 'W': 
      println("key w");
      y = y - 51;
      if (y == 18){
      y = 46;
      }
      if (y < 18){
      y = 630;
      level = level + 1;
      } 
      break;
    case 's':
    case 'S':
      println("key s");
      y = y + 51;
      if (y > 630){
        y = 630;
      }     
      break; 
    case 'd':
    case 'D':
      println("key d"); 
      x = x + 51 ;
      if (x > 898){
        x = 949; 
      }   
      break;
    case 'a':
    case 'A':
      println("key a");
      x = x - 51;
      if (x < 50){
        x = 50;
      }  
      break;
  } 
}

public void collision(){
  for (int i = 0; i < cars.length; i++ ) {
    if (x < cars[i].x + car0.height && x + Char.height >cars[i].x && 
    y <cars[i].y + car0.height && Char.height + y > cars[i].y) {
      switch (level){
        case 1:
          y = y + 51;
          break;
        case 2: 
           y = y + 102;
           break;
        case 3:
          y = 630;
        case 4: 
          y = 630;
          for (int j = 0; j < cars.length; j++ ) {
            if (j % 2 == 0){
              println("velocidade anterior do carro "+ j + " = "+ cars[j].speed);
              cars[j].speed =cars[j].speed++;
              cars[j].update(1);
              println("nova velocidade do carro "+ j + " = "+ cars[j].speed);
            }
          }
          break;
        case 5: 
          y = 630;
          for (int j = 0; j < cars.length; j++ ) { 
            cars[j].update(1);
          }
          break;
        default:
          y = 630;
          for (int j = 0; j < cars.length; j++ ) { 
            if(level_previous < level){
              retry = 0;
            }
            if (retry < 4){
              cars[j].update(2); 
              retry++;
              println(retry);
              level_previous = level;
              break;
            }           
           }
          break;
      } 
      
      if (y > 630){
        y = 630;
      }

    } 
  }
} 
class Cars{
  int x, y, style, speed;

  Cars(int x_, int y_, int _style){
    x = x_;
    y = y_;
    style = _style; 
    speed = (int) random(1,5) + level;
    
    if (style % 2 ==1){
      speed = speed * (-1);
    }
  }

  public void update(int penalty) {
    if (style % 2 ==1){
      speed = speed - penalty;
    }else{
      speed = speed + penalty;
    }

    if (speed > 0){
      x = x + (speed);
      if (x > 898){
        x = 50; 
      } 
    } 
    else{
      x = x + (speed);
      if (x < 50){
        x = 940;
      } 
    } 
  }

  public void display(int s){
    switch(s){
      case 0:
        image(car0, x, y, Char.width, Char.height); 
        break;
      case 1:
        image(car1, x, y, Char.width, Char.height);      
        break; 
      case 2:
        image(car2, x, y, Char.width, Char.height); 
        break;
      case 3:
        image(car3, x, y, Char.width, Char.height); 
        break;
    }
  }
}
  public void settings() {  size(1100, 720); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Freeway" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
